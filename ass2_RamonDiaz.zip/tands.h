extern void Trans( int n );
extern void Sleep( int n );