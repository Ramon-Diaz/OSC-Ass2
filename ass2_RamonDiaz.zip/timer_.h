#ifndef timer_
#define timer_

extern double get_time(clock_t timer);

#endif
